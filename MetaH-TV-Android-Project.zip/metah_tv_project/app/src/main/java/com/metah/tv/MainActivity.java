package com.metah.tv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int navy = Color.rgb(7,20,38), panel = Color.rgb(16,36,61), gold = Color.rgb(240,184,75), white = Color.WHITE;
    private EditText server, username, password, m3uUrl;
    private LinearLayout results;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ArrayList<Channel> channels = new ArrayList<>();

    static class Channel { String name, url, group; Channel(String n,String u,String g){name=n;url=u;group=g;} }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(navy); getWindow().setNavigationBarColor(navy);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(navy);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(20),dp(22),dp(28)); scroll.addView(root);
        TextView logo = text("MetaH TV", 34, gold, true); logo.setGravity(Gravity.CENTER); root.addView(logo, match());
        TextView subtitle = text("مشغّل القنوات والوسائط", 16, white, false); subtitle.setGravity(Gravity.CENTER); root.addView(subtitle, match());
        root.addView(gap(18));
        root.addView(section("اتصال Xtream Codes"));
        server = field("رابط الخادم مثال: https://server.example:8080"); root.addView(server, match());
        username = field("اسم المستخدم"); root.addView(username, match());
        password = field("كلمة المرور"); password.setInputType(129); root.addView(password, match());
        Button xtream = button("اتصال وتحميل القنوات"); root.addView(xtream, match()); xtream.setOnClickListener(v -> loadXtream());
        root.addView(gap(12)); root.addView(section("قائمة M3U / M3U8"));
        m3uUrl = field("رابط قائمة M3U المصرح لك باستخدامها"); root.addView(m3uUrl, match());
        Button m3u = button("تحميل قائمة M3U"); root.addView(m3u, match()); m3u.setOnClickListener(v -> loadM3u());
        root.addView(gap(16)); root.addView(section("القنوات"));
        results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); root.addView(results, match());
        TextView foot = text("تستخدم فقط قوائم وروابط تملك حق الوصول إليها.", 12, Color.LTGRAY, false); foot.setPadding(4,dp(20),4,4); root.addView(foot, match());
        setContentView(scroll);
    }

    private void loadXtream() {
        final String base=server.getText().toString().trim().replaceAll("/+$", ""), user=username.getText().toString().trim(), pass=password.getText().toString().trim();
        if(base.isEmpty()||user.isEmpty()||pass.isEmpty()){toast("أدخل رابط الخادم واسم المستخدم وكلمة المرور");return;}
        hideKeyboard(); setStatus("جارٍ الاتصال بالخادم…");
        worker.execute(() -> { try {
            String api=base+"/player_api.php?username="+enc(user)+"&password="+enc(pass)+"&action=get_live_streams";
            String body=get(api); JSONArray arr=new JSONArray(body); ArrayList<Channel> found=new ArrayList<>();
            for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o==null)continue; String name=o.optString("name","قناة بدون اسم"); String id=o.optString("stream_id",""); String ext=o.optString("container_extension","ts"); if(!id.isEmpty()) found.add(new Channel(name,base+"/live/"+enc(user)+"/"+enc(pass)+"/"+id+"."+ext,"بث مباشر"));}
            runOnUiThread(() -> { channels.clear(); channels.addAll(found); renderChannels(); toast(found.size()>0?"تم تحميل "+found.size()+" قناة":"لم تُعثر على قنوات؛ تحقق من بيانات الخادم"); });
        } catch(Exception e){runOnUiThread(() -> {setStatus("تعذر الاتصال: تحقق من الرابط والبيانات والإنترنت.");toast("فشل الاتصال بالخادم");});} });
    }

    private void loadM3u() {
        String link=m3uUrl.getText().toString().trim(); if(link.isEmpty()){toast("أدخل رابط قائمة M3U");return;} hideKeyboard(); setStatus("جارٍ تحميل قائمة M3U…");
        worker.execute(() -> { try {
            String body=get(link); String[] lines=body.split("\\r?\\n"); ArrayList<Channel> found=new ArrayList<>(); String name="قناة"; String group="";
            for(String raw:lines){String line=raw.trim(); if(line.startsWith("#EXTINF")){int comma=line.lastIndexOf(','); name=comma>=0?line.substring(comma+1).trim():"قناة"; int gi=line.indexOf("group-title=\""); if(gi>=0){int end=line.indexOf('"',gi+13); if(end>gi)group=line.substring(gi+13,end);} } else if(!line.isEmpty()&&!line.startsWith("#")&&(line.startsWith("http://")||line.startsWith("https://"))){found.add(new Channel(name,line,group));name="قناة";group="";}}
            runOnUiThread(() -> {channels.clear();channels.addAll(found);renderChannels();toast(found.size()>0?"تم تحميل "+found.size()+" قناة":"لم تُعثر على قنوات في القائمة");});
        } catch(Exception e){runOnUiThread(() -> {setStatus("تعذر تحميل القائمة. تحقق من الرابط وصلاحيته.");toast("فشل تحميل M3U");});} });
    }

    private void renderChannels(){results.removeAllViews(); if(channels.isEmpty()){results.addView(text("لم يتم تحميل قنوات بعد.",14,Color.LTGRAY,false));return;} for(Channel c:channels){Button b=button("▶  "+c.name+(c.group.isEmpty()?"":"  ·  "+c.group)); b.setGravity(Gravity.CENTER_VERTICAL|Gravity.START); b.setOnClickListener(v->{Intent i=new Intent(this,PlayerActivity.class);i.putExtra("url",c.url);i.putExtra("name",c.name);startActivity(i);});results.addView(b,match());}}
    private String get(String address)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("User-Agent","MetaH-TV/1.0");try{int code=c.getResponseCode();InputStream in=code>=200&&code<400?c.getInputStream():c.getErrorStream();if(in==null)throw new Exception("HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l).append('\n');if(code<200||code>=400)throw new Exception("HTTP "+code);return s.toString();}finally{c.disconnect();}}
    private String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
    private void setStatus(String s){results.removeAllViews();TextView t=text(s,14,Color.LTGRAY,false);results.addView(t);}
    private TextView section(String s){TextView t=text(s,18,gold,true);t.setPadding(0,dp(8),0,dp(8));return t;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(white);e.setHintTextColor(Color.LTGRAY);e.setHint(hint);e.setTextSize(15);e.setPadding(dp(12),dp(8),dp(12),dp(8));e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold));e.setSelectAllOnFocus(false);return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(white);b.setTextSize(14);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));b.setFocusable(true);b.setFocusableInTouchMode(true);b.setPadding(dp(10),dp(8),dp(10),dp(8));return b;}
    private LinearLayout.LayoutParams match(){return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);} private View gap(int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return v;} private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void hideKeyboard(){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(server.getWindowToken(),0);}catch(Exception ignored){}}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
