package com.metah.tv;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends Activity {
    private ExoPlayer player;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);
        String url=getIntent().getStringExtra("url");String name=getIntent().getStringExtra("name");
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);
        PlayerView view=new PlayerView(this);view.setUseController(true);root.addView(view,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        TextView label=new TextView(this);label.setText(name==null?"MetaH TV":name);label.setTextColor(Color.WHITE);label.setTextSize(16);label.setPadding(18,14,18,14);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT,android.view.Gravity.TOP|android.view.Gravity.START);root.addView(label,lp);setContentView(root);
        player=new ExoPlayer.Builder(this).build();view.setPlayer(player);if(url!=null&&!url.trim().isEmpty()){player.setMediaItem(MediaItem.fromUri(url));player.prepare();player.play();}
    }
    @Override protected void onStop(){super.onStop();if(player!=null){player.release();player=null;}}
}
